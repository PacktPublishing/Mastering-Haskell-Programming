#!/bin/bash
set -e

course &

# wait for the child process to terminate
wait
