









        -------------------------------------------------
        --                                             --
        --        Mastering Haskell Programming        --
        --                                             --
        --                         by Samuel Gélineau  --
        --                         published by Packt  --
        --                                             --
        -------------------------------------------------









































main :: IO ()
main = putStrLn "Welcome to the course!"
